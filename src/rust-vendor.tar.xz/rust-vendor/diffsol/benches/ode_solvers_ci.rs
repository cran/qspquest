use std::time::Duration;

use criterion::{criterion_group, criterion_main, Criterion};
use diffsol::{
    ode_equations::test_models::{
        exponential_decay::exponential_decay_problem, foodweb::foodweb_problem,
        heat2d::heat2d_problem, robertson::robertson, robertson_ode::robertson_ode,
    },
    FaerLU, FaerMat, FaerSparseLU, FaerSparseMat, NalgebraLU, NalgebraMat,
};

mod common;
use common::{bench_explicit, bench_implicit, bench_implicit_cg, bench_implicit_rt};

fn criterion_benchmark(c: &mut Criterion) {
    // 10 samples over a second is criterion's floor, and it made the CI numbers useless: the
    // runs are compared against a distribution collected on other GitHub runners, so the
    // per-run noise has to be well under the regression we want to catch.  The problems are
    // built outside the timed loop (see `common::setup_problem`), which keeps this affordable.
    *c = std::mem::take(c)
        .measurement_time(Duration::from_secs(3))
        .sample_size(50)
        .warm_up_time(Duration::from_secs(1));

    // -------------------------------------------------------------------------
    // Exponential Decay
    // -------------------------------------------------------------------------
    {
        let mut g = c.benchmark_group("exponential_decay_ci");
        bench_implicit!(
            g,
            nalgebra_bdf,
            bdf,
            NalgebraLU,
            exponential_decay_problem,
            NalgebraMat<f64>
        );
        bench_implicit!(
            g,
            nalgebra_esdirk34,
            esdirk34,
            NalgebraLU,
            exponential_decay_problem,
            NalgebraMat<f64>
        );
        bench_implicit!(
            g,
            nalgebra_tr_bdf2,
            tr_bdf2,
            NalgebraLU,
            exponential_decay_problem,
            NalgebraMat<f64>
        );
        bench_explicit!(
            g,
            nalgebra_tsit45,
            tsit45,
            exponential_decay_problem,
            NalgebraMat<f64>
        );
        bench_implicit!(
            g,
            faer_bdf,
            bdf,
            FaerLU,
            exponential_decay_problem,
            FaerMat<f64>
        );
        bench_implicit!(
            g,
            faer_esdirk34,
            esdirk34,
            FaerLU,
            exponential_decay_problem,
            FaerMat<f64>
        );
        bench_implicit!(
            g,
            faer_tr_bdf2,
            tr_bdf2,
            FaerLU,
            exponential_decay_problem,
            FaerMat<f64>
        );
        g.finish();
    }

    // -------------------------------------------------------------------------
    // Robertson
    // -------------------------------------------------------------------------
    {
        let mut g = c.benchmark_group("robertson_ci");
        bench_implicit!(
            g,
            nalgebra_bdf,
            bdf,
            NalgebraLU,
            robertson,
            NalgebraMat<f64>
        );
        bench_implicit!(
            g,
            nalgebra_esdirk34,
            esdirk34,
            NalgebraLU,
            robertson,
            NalgebraMat<f64>
        );
        bench_implicit!(
            g,
            nalgebra_tr_bdf2,
            tr_bdf2,
            NalgebraLU,
            robertson,
            NalgebraMat<f64>
        );
        bench_implicit!(g, faer_bdf, bdf, FaerLU, robertson, FaerMat<f64>);
        bench_implicit!(g, faer_esdirk34, esdirk34, FaerLU, robertson, FaerMat<f64>);
        bench_implicit!(g, faer_tr_bdf2, tr_bdf2, FaerLU, robertson, FaerMat<f64>);
        g.finish();
    }

    // -------------------------------------------------------------------------
    // Robertson ODE (dense, one small system per batch lane, reduced sizes for CI)
    // -------------------------------------------------------------------------
    {
        let mut g = c.benchmark_group("robertson_ode_ci");
        bench_implicit_rt!(
            g,
            nalgebra_bdf,
            bdf,
            NalgebraLU,
            robertson_ode,
            NalgebraMat<f64>,
            25,
            100
        );
        bench_implicit_rt!(
            g,
            nalgebra_tr_bdf2,
            tr_bdf2,
            NalgebraLU,
            robertson_ode,
            NalgebraMat<f64>,
            25,
            100
        );
        bench_implicit_rt!(
            g,
            nalgebra_esdirk,
            esdirk34,
            NalgebraLU,
            robertson_ode,
            NalgebraMat<f64>,
            25,
            100
        );
        g.finish();
    }

    // -------------------------------------------------------------------------
    // Heat2D (sparse, reduced sizes for CI)
    // -------------------------------------------------------------------------
    {
        let mut g = c.benchmark_group("heat2d_ci");
        bench_implicit_cg!(
            g,
            faer_sparse_bdf,
            bdf,
            FaerSparseLU,
            heat2d_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        bench_implicit_cg!(
            g,
            faer_sparse_tr_bdf2,
            tr_bdf2,
            FaerSparseLU,
            heat2d_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        bench_implicit_cg!(
            g,
            faer_sparse_esdirk,
            esdirk34,
            FaerSparseLU,
            heat2d_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        g.finish();
    }

    // -------------------------------------------------------------------------
    // Foodweb (sparse, reduced sizes for CI)
    // -------------------------------------------------------------------------
    {
        let mut g = c.benchmark_group("foodweb_ci");
        bench_implicit_cg!(
            g,
            faer_sparse_bdf,
            bdf,
            FaerSparseLU,
            foodweb_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        bench_implicit_cg!(
            g,
            faer_sparse_tr_bdf2,
            tr_bdf2,
            FaerSparseLU,
            foodweb_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        bench_implicit_cg!(
            g,
            faer_sparse_esdirk,
            esdirk34,
            FaerSparseLU,
            foodweb_problem,
            FaerSparseMat<f64>,
            5,
            10
        );
        g.finish();
    }
}

criterion_group!(benches, criterion_benchmark);
criterion_main!(benches);
