# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0](https://github.com/martinjrobins/diffsol/compare/diffsol-la-v0.2.0...diffsol-la-v0.3.0) - 2026-10-20

### Added

- *(diffsol)* vjp and jvp of step for OdeSolverMethods ([#409](https://github.com/martinjrobins/diffsol/pull/409))
- *(diffsol-la)* add transposed linear solve ([#406](https://github.com/martinjrobins/diffsol/pull/406))
- *(diffsol-la)* support f32 for cuda-oxide, deprecate C cuda feature ([#387](https://github.com/martinjrobins/diffsol/pull/387))
- *(diffsol-la)* make cuda-oxide containers generic on ScalarCuda ([#386](https://github.com/martinjrobins/diffsol/pull/386))
- *(diffsol-la)* generic cuda-oxide kernels ([#381](https://github.com/martinjrobins/diffsol/pull/381))

### Other

- *(diffsol-la)* [**breaking**] remove old nalgebra LU solver keeping only non-allocating LU ([#417](https://github.com/martinjrobins/diffsol/pull/417))

## [0.2.0](https://github.com/martinjrobins/diffsol/compare/diffsol-la-v0.1.1...diffsol-la-v0.2.0) - 2026-09-21

### Added

- *(diffsol-la)* [**breaking**] for_each_batch, for_each_elem + device/host variants ([#375](https://github.com/martinjrobins/diffsol/pull/375))
- *(diffsol-la)* new cuda-oxide LA backend ([#374](https://github.com/martinjrobins/diffsol/pull/374))
- *(diffsol)* [**breaking**] sensitivity/adjoints calculated by batching ([#373](https://github.com/martinjrobins/diffsol/pull/373))
- *(diffsol-la)* [**breaking**] allow grouped batching B -> C * B, owned side has priority, then lhs ([#370](https://github.com/martinjrobins/diffsol/pull/370))
- *(diffsol)* [**breaking**] refactor Tableau and Bdf to use new SmallVec and SmallMat ([#369](https://github.com/martinjrobins/diffsol/pull/369))
- *(diffsol-la)* add batching for cpu backends ([#361](https://github.com/martinjrobins/diffsol/pull/361))

### Fixed

- *(diffsol-la)* faer lu solvers honor par ([#376](https://github.com/martinjrobins/diffsol/pull/376))

### Other

- examples for cpu + gpu parallel ensembles, example for batching and book sections ([#377](https://github.com/martinjrobins/diffsol/pull/377))
- *(diffsol-la)* use native faer matmul for sparse gemv ([#367](https://github.com/martinjrobins/diffsol/pull/367))
- *(diffsol-na)* add fast pow path for newton convergence ([#366](https://github.com/martinjrobins/diffsol/pull/366))
- *(diffsol-la)* non-allocating nalgebra lu solver ([#364](https://github.com/martinjrobins/diffsol/pull/364))
- *(diffsol-la)* use new rustc algebraic floating point ops for reductions (feature gated for now) ([#363](https://github.com/martinjrobins/diffsol/pull/363))
- *(diffsol-la)* replace column_axpy kernel with fused backwards_diff_update ([#362](https://github.com/martinjrobins/diffsol/pull/362))

## [0.1.1](https://github.com/martinjrobins/diffsol/compare/diffsol-la-v0.1.0...diffsol-la-v0.1.1) - 2026-08-18

### Fixed

- look up row indices through `row_idx` in MatrixSparsity::indices ([#342](https://github.com/martinjrobins/diffsol/pull/342))
- consistent capitalisation of diffsol ([#336](https://github.com/martinjrobins/diffsol/pull/336))

### Other

- builder and tolerances sections ([#346](https://github.com/martinjrobins/diffsol/pull/346))
