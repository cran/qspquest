//! # diffsol-la
//!
//! Linear algebra traits and backends for [diffsol](https://github.com/martinjrobins/diffsol).
//!
//! This crate provides the vector, matrix, and linear-solver abstractions used by
//! diffsol, together with concrete implementations backed by
//! [nalgebra](https://nalgebra.org), [faer](https://github.com/sarah-ek/faer-rs),
//! suitesparse (KLU), and CUDA.

/// Context objects for managing device resources for vectors and matrices (e.g. device streams, threading pools, etc.).
///
/// This module provides context types that encapsulate information about where data is stored and computed
/// (CPU, GPU, etc.). Different backends like nalgebra and faer may require different context implementations.
/// The [Context] trait defines the interface that must be implemented.
pub mod context;

#[cfg(feature = "cuda-oxide")]
pub(crate) mod cuda_oxide_kernels;

/// Error types and handling.
///
/// This module defines the [LaError] enum and specialized error variants for
/// the linear algebra layer, including matrix, linear-solver, and (optional)
/// CUDA errors.
pub mod error;

/// The [LinearOp] trait describing a linear operator `A` for use with [LinearSolver].
pub mod linear_op;

/// Linear solver implementations and traits.
///
/// This module defines the [LinearSolver] trait for solving linear systems and provides implementations:
/// - Direct solvers: [NalgebraLU], [FaerLU], [FaerSparseLU]
/// - Optional sparse solvers: `KLU` (requires `suitesparse` feature)
/// - GPU solvers: `OxideLU` (requires `cuda-oxide` feature), `CudaLU` (deprecated, requires `cuda` feature)
///
/// The linear solver is a critical component used internally by nonlinear solvers to solve Newton systems.
pub mod linear_solver;

/// Matrix types and operations.
///
/// This module defines the [Matrix] trait and related traits for matrix operations:
/// - [DenseMatrix] for dense column-major matrices
/// - Sparsity detection and handling
///
/// Implementations are provided for:
/// - Dense matrices: [NalgebraMat], [FaerMat]
/// - Sparse matrices: [FaerSparseMat]
/// - GPU matrices: `OxideMat` (requires `cuda-oxide` feature), `CudaMat` (deprecated, requires `cuda` feature)
pub mod matrix;

/// Scalar types and traits.
///
/// This module defines the [Scalar] trait that all floating-point types used in diffsol must implement.
/// It aggregates requirements from nalgebra, faer, and num_traits to ensure compatibility with linear algebra operations.
///
/// Implementations are provided for `f32` and `f64`.
/// GPU scalar types are available via `ScalarCuda` (requires `cuda-oxide` or `cuda` feature).
pub mod scalar;

/// Vector types and traits.
///
/// This module defines the [Vector] trait and related traits for vector operations:
/// - [VectorView] and [VectorViewMut] for borrowed views
/// - [VectorIndex] for index collections
///
/// Implementations are provided for:
/// - [NalgebraVec] using nalgebra vectors
/// - [FaerVec] using faer vectors
/// - `OxideVec` for GPU computation (requires `cuda-oxide` feature), `CudaVec` (deprecated, requires `cuda` feature)
pub mod vector;

pub use error::LaError;

pub use context::{faer::FaerContext, nalgebra::NalgebraContext, Context};

pub use linear_op::LinearOp;
pub use linear_solver::LinearSolver;
pub use linear_solver::{faer::sparse_lu::FaerSparseLU, FaerLU, NalgebraLU};

#[cfg(feature = "suitesparse")]
pub use linear_solver::suitesparse::klu::KLU;

pub use matrix::{
    default_solver::DefaultSolver, dense_faer_serial::FaerMat, dense_nalgebra_serial::NalgebraMat,
    sparse_faer::FaerSparseMat, DenseMatrix, Matrix, MatrixCommon,
};

pub(crate) use matrix::extract_block::ColMajBlock;
pub use matrix::{
    sparsity::Dense, sparsity::DenseRef, sparsity::MatrixSparsity, sparsity::MatrixSparsityRef,
    MatrixRef,
};

pub use scalar::{scale, FaerScalar, IndexType, NalgebraScalar, Scalar, Scale};

pub use vector::DefaultDenseMatrix;
pub use vector::{
    faer_serial::{FaerVec, FaerVecIndex, FaerVecMut, FaerVecRef},
    nalgebra_serial::{NalgebraVec, NalgebraVecMut, NalgebraVecRef},
    Vector, VectorCommon, VectorIndex, VectorRef, VectorView, VectorViewMut,
};

#[cfg(feature = "cuda")]
#[allow(deprecated)]
pub use context::cuda::CudaContext;
#[cfg(feature = "cuda")]
#[allow(deprecated)]
pub use linear_solver::cuda::lu::CudaLU;
#[cfg(feature = "cuda")]
#[allow(deprecated)]
pub use matrix::cuda::CudaMat;
#[cfg(any(feature = "cuda", feature = "cuda-oxide"))]
pub use scalar::cuda::{CudaType, ScalarCuda};
#[cfg(feature = "cuda")]
#[allow(deprecated)]
pub use vector::cuda::{CudaIndex, CudaVec, CudaVecMut, CudaVecRef};

#[cfg(feature = "cuda-oxide")]
pub use context::cuda_oxide::OxideContext;
#[cfg(feature = "cuda-oxide")]
pub use linear_solver::cuda_oxide::lu::OxideLU;
#[cfg(feature = "cuda-oxide")]
pub use matrix::cuda_oxide::OxideMat;
#[cfg(feature = "cuda-oxide")]
pub use vector::cuda_oxide::{OxideIndex, OxideVec, OxideVecMut, OxideVecRef};
